﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimulacroParcial1.Presentacion
{
    public partial class FrmReporteStock : Form
    {
        public FrmReporteStock()
        {
            InitializeComponent();
        }

        private void FrmReporteStock_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dataSetStock.SP_CONSULTAR_MATERIALES' Puede moverla o quitarla según sea necesario.
            this.sP_CONSULTAR_MATERIALESTableAdapter.Fill(this.dataSetStock.SP_CONSULTAR_MATERIALES);

            this.reportViewer1.RefreshReport();
        }
    }
}
