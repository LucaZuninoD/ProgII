﻿namespace SimulacroParcial1.Datos
{


    partial class DataSetStock
    {
        partial class MaterialDataTable
        {
        }
    }
}
